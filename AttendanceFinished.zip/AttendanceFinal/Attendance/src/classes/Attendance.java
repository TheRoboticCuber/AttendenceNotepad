package classes;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import java.awt.Rectangle;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Attendance {
	
	public static String displayText = "";
	public static int inputID = -918273645;
	public Shell shlRobostangsAttendance;
	public Text IDInput;
	public static Label lblNewLabel_1;
	public static boolean primeConfirm = false;
	public static boolean isConfirm = false;
	public static boolean end = false;
	
	/**
	 * Open the window.
	 */
	public void openGUI() {
		inputID = -918273645;
		primeConfirm = false;
		isConfirm = false;
		Display display = Display.getDefault();
		createContents();
		shlRobostangsAttendance.open();
		shlRobostangsAttendance.layout();
		boolean stop = false;
		while (!stop) {
			//auto generated code
			if (!display.readAndDispatch()) {
				display.sleep();
			}
			//
			if (!Interface.getName(inputID).contentEquals("nameNotFound")) {
				if (!isConfirm&&Interface.isSignedIn(inputID)) {
					setLabel("You are currently signed in. Please press the button again to sign out.");
					primeConfirm = true;
				} else if (!isConfirm&&!Interface.isSignedIn(inputID)) {
					setLabel("You are currently signed out. Please press the button again to sign in.");
					primeConfirm = true;
				} else {
					stop = true;
				}
			} else if (inputID != -918273645) {
				setLabel("The ID that you have input was not found, please try a different one");
			}
//			!shlRobostangsAttendance.isDisposed()
		}
		shlRobostangsAttendance.close();
	}

	/**
	 * Create contents of the window.
	 */
	public void createContents() {
		shlRobostangsAttendance = new Shell(Display.getDefault(), SWT.RESIZE);
		org.eclipse.swt.graphics.Rectangle screenSize = Display.getDefault().getBounds();
		shlRobostangsAttendance.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		shlRobostangsAttendance.setSize(450, 300);
		shlRobostangsAttendance.setLocation((screenSize.width - shlRobostangsAttendance.getBounds().width) / 2, (screenSize.height - shlRobostangsAttendance.getBounds().height) / 2);
		shlRobostangsAttendance.setText("Robostangs Attendance");
		
		IDInput = new Text(shlRobostangsAttendance, SWT.BORDER);
		IDInput.setBackground(SWTResourceManager.getColor(255, 255, 255));
		IDInput.setBounds(174, 151, 75, 21);
		
		Label lblUsername = new Label(shlRobostangsAttendance, SWT.NONE);
		lblUsername.setFont(SWTResourceManager.getFont("Segoe UI", 11, SWT.NORMAL));
		lblUsername.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblUsername.setForeground(SWTResourceManager.getColor(255, 140, 0));
		lblUsername.setBounds(29, 150, 85, 26);
		lblUsername.setText("ID Number:");
		
		Label lblRobostangsAttendance = new Label(shlRobostangsAttendance, SWT.NONE);
		lblRobostangsAttendance.setFont(SWTResourceManager.getFont("Segoe UI", 13, SWT.NORMAL));
		lblRobostangsAttendance.setAlignment(SWT.CENTER);
		lblRobostangsAttendance.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblRobostangsAttendance.setForeground(SWTResourceManager.getColor(255, 140, 0));
		lblRobostangsAttendance.setBounds(120, 45, 194, 32);
		lblRobostangsAttendance.setText("Robostangs Attendance");
		
		Button btnSignIn = new Button(shlRobostangsAttendance, SWT.NONE);
//		frame.getRootPane().setDefaultButton(btnSignIn);

		btnSignIn.setForeground(SWTResourceManager.getColor(255, 140, 0));
		btnSignIn.setBounds(174, 226, 75, 25);
		btnSignIn.setText("Sign In / Out");
		
		Label lblNewLabel = new Label(shlRobostangsAttendance, SWT.NONE);
		lblNewLabel.setImage(SWTResourceManager.getImage(System.getProperty("user.dir") + "\\robostangsmall.png"));
		lblNewLabel.setBounds(10, 10, 104, 104);
		
		Label label = new Label(shlRobostangsAttendance, SWT.HORIZONTAL);
		label.setImage(SWTResourceManager.getImage(System.getProperty("user.dir") + "\\robostangsmall.png"));
		label.setBounds(320, 10, 104, 104);
		
		lblNewLabel_1 = new Label(shlRobostangsAttendance, SWT.NONE);
		lblNewLabel_1.setForeground(SWTResourceManager.getColor(255, 140, 0));
		lblNewLabel_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		lblNewLabel_1.setBounds(20, 182, 400, 26);
		lblNewLabel_1.setText(displayText);
		
		btnSignIn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				inputID = Interface.getIntFromString(IDInput.getText());
				if (IDInput.getText().contentEquals("END")) {
					end = true;
					shlRobostangsAttendance.close();
				}
				System.out.println(IDInput.getText());
				if (primeConfirm) {
					isConfirm = true;
				}
			}
		});
	}
	public static void setLabel(String text) {
		lblNewLabel_1.setText(text);
	}
}
