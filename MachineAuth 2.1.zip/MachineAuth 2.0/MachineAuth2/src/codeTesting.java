import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;

public class codeTesting {
	public static void main(String[] args) {
		Interface.createOutputFile();
		Interface.outputToLog(2, 2, true, "");
		
		/*
		Date currentDateTime = Calendar.getInstance().getTime();
		DateFormat currentYear = new SimpleDateFormat("yyyy");
		DateFormat currentMonth = new SimpleDateFormat("MMMM");
		DateFormat currentDay= new SimpleDateFormat("dd");
		String year = currentYear.format(currentDateTime);
		String month = currentMonth.format(currentDateTime);
		String day= currentDay.format(currentDateTime);
		System.out.println(year + ";" + month + ";" + day);
		String outputFileDir = System.getProperty("user.dir") + "\\" + year + "\\" + month;
		File file = new File(outputFileDir);
		System.out.println(file.exists());
		System.out.println(file.mkdirs());
		System.out.println(file.exists());
		file = new File(outputFileDir + "\\" + day + ".txt");
		try {
			System.out.println(file.createNewFile());
		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
		
		/*
		System.out.println(System.getProperty("user.dir"));
		File file = new File(System.getProperty("user.dir") + "\\newFile.txt");
		try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		/*
		ArrayList<String> doc = new ArrayList<String>();
		BufferedWriter bw = null;
		BufferedReader br = null;
		String line;
		try {
			br = new BufferedReader(new FileReader("outputLog.txt"));
			while ((line = br.readLine()) != null) {
				doc.add(line);
			}
			br.close();
			bw = new BufferedWriter(new FileWriter("outputLog.txt"));
			for (int i = 0; i < doc.size(); i++) {
				bw.write(doc.get(i));
				bw.newLine();
			}
			for (int i = 0; i < 10; i++) {
				bw.write("wussdnjo" + i);
				bw.newLine();
			}
			System.out.println("Success");
		}
		catch (IOException e){
			e.printStackTrace();
		}
		finally {
			try {
				if(bw!=null) {
					bw.close();
				}
			} catch(Exception ex) {
				System.out.println("Error in closing the BufferedWriter"+ex);
			}
		}
  		*/
	}
}