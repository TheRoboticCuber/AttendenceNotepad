package org.eclipse.wb.swt;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Attendance {

	protected Shell shlRobostangsAttendance;
	private Text IDinput;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Attendance window = new Attendance();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlRobostangsAttendance.open();
		shlRobostangsAttendance.layout();
		while (!shlRobostangsAttendance.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlRobostangsAttendance = new Shell();
		shlRobostangsAttendance.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		shlRobostangsAttendance.setSize(450, 300);
		shlRobostangsAttendance.setText("Robostangs Attendance");
		
		IDinput = new Text(shlRobostangsAttendance, SWT.BORDER);
		IDinput.setBackground(SWTResourceManager.getColor(255, 255, 255));
		IDinput.setBounds(174, 151, 75, 21);
		
		Label lblUsername = new Label(shlRobostangsAttendance, SWT.NONE);
		lblUsername.setFont(SWTResourceManager.getFont("Segoe UI", 11, SWT.NORMAL));
		lblUsername.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblUsername.setForeground(SWTResourceManager.getColor(255, 140, 0));
		lblUsername.setBounds(29, 150, 85, 26);
		lblUsername.setText("ID Number:");
		
		Label lblRobostangsAttendance = new Label(shlRobostangsAttendance, SWT.NONE);
		lblRobostangsAttendance.setFont(SWTResourceManager.getFont("Segoe UI", 13, SWT.NORMAL));
		lblRobostangsAttendance.setAlignment(SWT.CENTER);
		lblRobostangsAttendance.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblRobostangsAttendance.setForeground(SWTResourceManager.getColor(255, 140, 0));
		lblRobostangsAttendance.setBounds(120, 45, 194, 32);
		lblRobostangsAttendance.setText("Robostangs Attendance");
		
		Button btnSignIn = new Button(shlRobostangsAttendance, SWT.NONE);
		btnSignIn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
			}
		});
		btnSignIn.setForeground(SWTResourceManager.getColor(255, 140, 0));
		btnSignIn.setBounds(174, 226, 75, 25);
		btnSignIn.setText("Sign In / Out");
		
		Label lblNewLabel = new Label(shlRobostangsAttendance, SWT.NONE);
		lblNewLabel.setImage(SWTResourceManager.getImage(System.getProperty("user.dir") + "\\robostangsmall.png"));
		lblNewLabel.setBounds(10, 10, 104, 104);
		
		Label label = new Label(shlRobostangsAttendance, SWT.HORIZONTAL);
		label.setImage(SWTResourceManager.getImage(System.getProperty("user.dir") + "\\robostangsmall.png"));
		label.setBounds(320, 10, 104, 104);
		
		Label lblNewLabel_1 = new Label(shlRobostangsAttendance, SWT.NONE);
		lblNewLabel_1.setForeground(SWTResourceManager.getColor(255, 140, 0));
		lblNewLabel_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		lblNewLabel_1.setBounds(107, 182, 221, 26);
		lblNewLabel_1.setText("Sample Text");

	}
}
